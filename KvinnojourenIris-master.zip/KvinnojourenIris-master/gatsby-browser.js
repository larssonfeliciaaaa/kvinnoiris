import "./src/styles/tailwind.css"

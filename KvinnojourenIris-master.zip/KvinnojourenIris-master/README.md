<h1 align="center">
  Kvinnojouren Iris
</h1>

Kvinnojouren Iris is a women's shelter and a relief organisation that protects and supports women, young women and children exposed to men's violence and oppression.

Deployed on [Netlify](https://app.netlify.com/) with build hooks to automatically trigger builds on CMS updates.

### ❗️ Required env:

   ```shell
    GATSBY_GRAPHQL_IDE=playground
    CONTENTFUL_SPACEID=<SECRET_KEY>
    CONTENTFUL_ACCESS_TOKEN=<SECRET_KEY>
  ```

